package com.omni.y5citysdk.tool.viewpager_card;

public class CardItem {

    private int image_id;

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }
}

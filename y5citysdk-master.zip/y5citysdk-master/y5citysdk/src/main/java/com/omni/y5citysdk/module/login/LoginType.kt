package com.omni.y5citysdk.module.login

enum class LoginType {
    GOOGLE, FACEBOOK, SDK
}